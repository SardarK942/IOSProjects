//
//  PropertyCell.swift
//  Khan_Sardar_masterDetailApp
//
//  Created by Sardar Khan on 3/10/22.
//

import UIKit

class PropertyCell: UITableViewCell {

    @IBOutlet weak var propertyImageVIew: UIImageView!
    
    @IBOutlet weak var propertyAddressLabel: UILabel!
}
