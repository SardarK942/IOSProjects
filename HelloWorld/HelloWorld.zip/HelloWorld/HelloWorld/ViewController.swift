//
//  ViewController.swift
//  HelloWorld
//
//  Created by Sardar Khan on 1/12/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

